//
//  Contact+CoreDataClass.swift
//  StorageV1
//
//  Created by Ray Chen on 10/31/21.
//
//

import Foundation
import CoreData

@objc(Contact)
public class Contact: NSManagedObject {

}
