//
//  Identity+CoreDataClass.swift
//  StorageV1
//
//  Created by Ray Chen on 10/31/21.
//
//

import Foundation
import CoreData

@objc(Identity)
public class Identity: NSManagedObject {

}
