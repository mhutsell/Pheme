//
//  Encrypted+CoreDataClass.swift
//  StorageV1
//
//  Created by Ray Chen on 10/20/21.
//
//

import Foundation
import CoreData

@objc(Encrypted)
public class Encrypted: NSManagedObject {

}
