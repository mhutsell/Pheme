//
//  PrivateKey+CoreDataClass.swift
//  StorageV1
//
//  Created by Ray Chen on 10/16/21.
//
//

import Foundation
import CoreData

@objc(PrivateKey)
public class PrivateKey: NSManagedObject {

}
