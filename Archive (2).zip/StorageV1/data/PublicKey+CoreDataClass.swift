//
//  PublicKey+CoreDataClass.swift
//  StorageV1
//
//  Created by Ray Chen on 10/20/21.
//
//

import Foundation
import CoreData

@objc(PublicKey)
public class PublicKey: NSManagedObject {

}
