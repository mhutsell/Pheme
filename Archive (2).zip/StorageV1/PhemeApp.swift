//
//  PhemeApp.swift
//  Pheme
//
//  Created by Kunal Suri on 10/13/21.
//

import SwiftUI

@main
struct PhemeApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}
